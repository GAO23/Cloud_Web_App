
You need to run this pa03.py as root and using python3 so do sudo python3 ./pa03.py
Aguement is optional, if not specify, it defaults to local host
Usage: sudo python3 ./pa03.py <ip address>



