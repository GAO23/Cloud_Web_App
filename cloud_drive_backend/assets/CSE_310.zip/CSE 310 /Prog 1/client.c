#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char** argv) {

    if(argc != 4){
        printf("\nUsgae: %s <ip address> <port #> <object path>\n", *argv);
        exit(EXIT_FAILURE);
    }

    int client_sock;
    struct sockaddr_in serverAddr;
    char buffer[2048];
    client_sock = socket(AF_INET, SOCK_STREAM, 0);
    if(client_sock < 0){
        perror("client socket creation");
        exit(EXIT_FAILURE);
    }

    printf("\n[+]Client socket created\n");

    memset(&serverAddr, 0, sizeof(serverAddr));

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(atoi(argv[2]));
    serverAddr.sin_addr.s_addr = inet_addr(argv[1]);


    if(connect(client_sock, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) < 0){
        perror("connect error");
        exit(EXIT_FAILURE);
    }

    printf("\n[+] Connected to server\n");

    strcpy(buffer, "GET ");
    strcat(buffer, *(argv + 3));
    strcat(buffer, " HTTP/1.1\r\n\r\n");

    if(send(client_sock, buffer, strlen(buffer), 0) < 0){
        perror("send error");
        exit(EXIT_FAILURE);
    }

    printf("\nsent %s\n", buffer);

    if(recv(client_sock, buffer, 2048, 0) < 0){
        perror("receive error");
        exit(EXIT_FAILURE);
    }

    printf("\nreceived back from server this object \n%s\n", buffer);



    return 0;
}