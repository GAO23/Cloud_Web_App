First run the server in the bin folder. 
cd into the bin folder.
Give it execute permission: chmod +x server
then run: ./server

next run the client
In the same folder, run: chmod +x client
The client takes the these arguments: ./client <ip address> <port #> <file path>

For the purpose of this demonstration, I assume both the client and the server is ran on the same machine. In this case, run cleint with these parameter: ./client 127.0.0.1 6789 /index.html


If running on browser then type localhost:6789/index.html into your browser url

If running on different machine over the same network, you need to make sure the firewall configuration of the server machine allows incoming configuration. 

run this in the terminal: /sbin/iptables -A INPUT -m state --state NEW -m tcp -p tcp --dport 6789 -j ACCEPT
