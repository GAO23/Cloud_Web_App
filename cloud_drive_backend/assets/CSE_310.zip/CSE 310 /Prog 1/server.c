
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 6789

void send_html(int newSock, char buffer[], char buffer_tem[]);

int main(int argc, char** argv){

    int sockfd, newSock;
    struct sockaddr_in serverAddr, newAddr;
    FILE* html_data = fopen("index.html", "r");
    if(html_data == NULL){
        perror("fopen error");
        exit(EXIT_FAILURE);
    }


    char buffer[2048] = "HTTP/1.1 200 OK\r\n\n";
    char buffer_tem[2048];
    while(fgets(buffer_tem, 2048, html_data)){
        strcat(buffer, buffer_tem);
    }

    pid_t child;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if(sockfd < 0){
        perror("socket creation");
        exit(EXIT_FAILURE);
    }

    printf("\n[+]Server socket created\n");

    memset(&serverAddr, 0, sizeof(serverAddr));

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;


    if(bind(sockfd, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) < 0){
        perror("bind error");
        exit(EXIT_FAILURE);
    }

    printf("\n[+]Bind to port %d\n", PORT);

    if(listen(sockfd, 10) < 0){
        perror("Listening error");
        exit(EXIT_FAILURE);
    }

    while(1){
        socklen_t size = sizeof(newAddr);
        newSock = accept(sockfd, (struct sockaddr*) &newAddr, &size);
        if(newSock < 0){
            perror("Accpet error");
            exit(EXIT_FAILURE);
        }
        printf("\n[+]Accepted connection from %s:%d\n", inet_ntoa(newAddr.sin_addr), newAddr.sin_port);
        if((child = fork()) == 0){
            close(sockfd);
            recv(newSock, buffer_tem, 2048, 0);
            printf("\n[+]Got this request from client:\n%s\n", buffer_tem);
            send_html(newSock, buffer, buffer_tem);
            close(newSock);
            exit(EXIT_SUCCESS);
        }
        close(newSock);
    }



    return 0;
}

void send_html(int newSock, char buffer[], char buffer_tem[]){
    char error[] = "HTTP/1.1 404 Not Found\r\n\n<html><body>404 Not Found</body></html>";
    buffer_tem += 4;
    *(buffer_tem + 11) = 0;
    if(strcmp(buffer_tem, "/index.html") == 0){
        send(newSock, buffer, strlen(buffer), 0);
        printf("\n[+]sent back html\n %s \n", buffer);
    }else{
        if(send(newSock, error, sizeof(error), 0) < 0){
            perror("send error");
            close(newSock);
            exit(EXIT_FAILURE);
        }
        printf("\n[+]sent back html\n %s \n", error);
    }

}

